// 가족 공유 설정
// 1) Firebase 콘솔(https://console.firebase.google.com)에서 프로젝트를 만들고
// 2) "웹 앱 추가"를 누르면 나오는 firebaseConfig 값을 아래에 붙여 넣으세요.
// 3) Firestore Database 를 "테스트 모드"로 만들면 끝.
// 이 값을 비워 두면 각자 폰에만 저장되는 혼자 쓰기 모드로 동작합니다.
window.FAMILY_CONFIG = {
  familyId: "our-family",   // 가족 식별용 이름 (아무거나, 세 명이 같은 값)
  firebase: {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT_ID.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
  }
};
