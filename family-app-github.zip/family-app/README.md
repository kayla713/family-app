# 우리집 일정·용돈 앱

아빠 · 엄마 · 재빈 세 가족의 일정과 재빈이 용돈 기입장.

## 1. GitHub에 올리기 (한 번만, 엄마가)

1. GitHub에서 **New repository** → 이름 `family-app` → Public → Create.
2. 이 폴더의 파일 전부(index.html, config.js, manifest.json, sw.js, icon.svg, icon-192.png, icon-512.png)를 **Add file → Upload files** 로 올리고 Commit.
3. 저장소 **Settings → Pages → Branch: main / (root) → Save**.
4. 1~2분 뒤 `https://<아이디>.github.io/family-app/` 주소가 생깁니다. 이 주소를 가족에게 보내세요.

## 2. 가족 공유 켜기 (무료 Firebase, 5분)

이 단계를 건너뛰면 각자 폰에만 저장됩니다.

1. https://console.firebase.google.com → **프로젝트 추가** (이름 아무거나, 애널리틱스 끄기).
2. 왼쪽 **빌드 → Firestore Database → 데이터베이스 만들기 → 테스트 모드로 시작** → 위치 `asia-northeast3(서울)`.
3. 프로젝트 홈에서 **`</>` (웹 앱 추가)** → 앱 별명 입력 → 등록 → 화면에 나오는 `firebaseConfig` 의 값들을 복사.
4. GitHub 저장소에서 `config.js` 를 열어(연필 아이콘) `YOUR_...` 부분을 복사한 값으로 바꾸고 Commit.
5. 앱을 새로고침하면 아래에 **"가족 모두와 공유 중"** 이라고 뜹니다.

> 테스트 모드 규칙은 30일 뒤 만료됩니다. Firestore → 규칙 탭에서 아래처럼 바꿔 두면 계속 쓸 수 있어요
> (주소를 아는 사람은 누구나 쓸 수 있으니 가족끼리만 공유하세요):
> ```
> rules_version = '2';
> service cloud.firestore {
>   match /databases/{database}/documents {
>     match /families/{family}/{document=**} { allow read, write: if true; }
>   }
> }
> ```

## 3. 폰에 설치하기 (아빠, 엄마, 재빈 각자)

- **아이폰**: Safari로 주소 열기 → 공유 버튼 → **홈 화면에 추가**.
- **안드로이드**: Chrome으로 주소 열기 → 오른쪽 위 ⋮ → **홈 화면에 추가** (또는 설치).

설치 후 앱 상단 "나는" 에서 본인을 고르면 됩니다.
